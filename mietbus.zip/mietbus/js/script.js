
// var universal=document.querySelectorAll('*');
        // universal.setAttribute("style","margin:0;padding:0;box-sizing:border-box;");
        // document.body.appendChild(universal);

        var wrapper = document.createElement("div");
        document.body.appendChild(wrapper);
        wrapper.setAttribute("style", "background-color:#f1662f;padding:20px;");

        // wrapper.innerText="this is parar"

        var container = document.createElement("div");
        container.setAttribute("style", "margin:0 auto;width:964px;")
        wrapper.appendChild(container);

        var header = document.createElement('div');
        // header.innerText="this is div container";
        container.appendChild(header);

        var div1 = document.createElement('div');
        // div1.innerText="this is div container";
        div1.setAttribute("style", "display:flex; justify-content:space-between;");
        header.appendChild(div1);

        var logo = document.createElement('img');
        var url = 'images/logo.png';
        logo.src = url;

        div1.appendChild(logo);

        var parent = document.createElement("div");

        parent.setAttribute("style", "color:#fff;");
        div1.appendChild(parent);
        // var i1=document.createElement('i');
        // i1.innerHTML="<i class=fa fa-envelope-o></i>";
        // parent.appendChild(i1);
        var span1 = document.createElement("span");
        span1.innerHTML = "<i class='fa fa-envelope-o' style='margin:0px 8px 0px 0px;'></i>info@mietbus24.com";
        span1.setAttribute("style", "padding-right:20px;");
        parent.appendChild(span1);

        var span2 = document.createElement("span");
        span2.innerHTML = "<i class='fa fa-phone' style='margin:0px 8px 0px 0px;'></i>040 - 555 02 999 0";
        parent.appendChild(span2);

        // header end here



        var div2 = document.createElement("div");
        div2.setAttribute("style", "margin:0 auto;width:964px;");
        var nav = document.createElement('nav');

        nav.setAttribute('style',"margin:15px 0px;");
        div2.appendChild(nav);

        var ul = document.createElement('ul');
        ul.setAttribute("style", "list-style-type: none;");
        nav.appendChild(ul);


        var li1 = document.createElement("li");
        li1.setAttribute('style', 'display:inline-block; ');
        ul.appendChild(li1);

        var a = document.createElement('a');
        a.setAttribute('style', 'padding-right:15px;color:#f16131; font-size: 14px;;line-height: 34px;text-transform:uppercase;')
        li1.appendChild(a);
        var text = document.createTextNode('Start');
        a.appendChild(text);

        var li2 = document.createElement("li");
        li2.setAttribute('style', 'display:inline-block;');
        ul.appendChild(li2);

        var a = document.createElement('a');
        a.setAttribute('style', 'padding-right:15px;color:#595959; font-size: 14px;line-height: 34px;text-transform:uppercase;')
        li2.appendChild(a);
        var text = document.createTextNode(' Busanfrage ');
        a.appendChild(text);

        var li3 = document.createElement("li");
        li3.setAttribute('style', 'display:inline-block;');
        ul.appendChild(li3);

        var a = document.createElement('a');
        a.setAttribute('style', 'padding-right:15px;color:#595959; font-size: 14px;line-height: 34px;text-transform:uppercase;')
        li3.appendChild(a);
        var text = document.createTextNode('leistungen ');
        a.appendChild(text);

        var li4 = document.createElement("li");
        li4.setAttribute('style', 'display:inline-block;');
        ul.appendChild(li4);

        var a = document.createElement('a');
        a.setAttribute('style', 'padding-right:15px;color:#595959; font-size: 14px;line-height: 34px;text-transform:uppercase;')
        li4.appendChild(a);
        var text = document.createTextNode('Über uns');
        a.appendChild(text);


        var li5 = document.createElement("li");
        li5.setAttribute('style', 'display:inline-block;');
        ul.appendChild(li5);

        var a = document.createElement('a');
        a.setAttribute('style', 'padding-right:15px;color:#595959; font-size: 14px;line-height: 34px;text-transform:uppercase;')
        li5.appendChild(a);
        var text = document.createTextNode('FAQ ');
        a.appendChild(text);

        var li6 = document.createElement("li");
        li6.setAttribute('style', 'display:inline-block;');
        ul.appendChild(li6);

        var a = document.createElement('a');
        a.setAttribute('style', 'padding-right:15px;color:#595959; font-size: 14px;line-height: 34px;text-transform:uppercase;')
        li6.appendChild(a);
        var text = document.createTextNode(' Kontakt');
        a.appendChild(text);

        document.body.appendChild(div2);


        var div3 = document.createElement("div");
        div3.setAttribute('style', 'background-image:url(images/back.jpg);background-repeat: no-repeat;background-size: cover;padding:158px 385px;');
        // div3.innerHTML="<h1>this is heading</h1>"
        // div3.innerHTML="<p>lorem para one this paragarph </p>"
        div3.innerHTML = "<form style=' background-color: #ded1c9; border-radius: 5px; padding: 5px 0px;  height:67px; width:691px;    text-align: center;    border: none;'><input type='text' placeholder='Zielort?' style='padding:20px;border:none;border-radius: 6px;color:#909090;'><input type='text' placeholder='Personen?' style='padding:20px;border-radius: 6px;text-color:#909090;border:none;margin-left:3px'><input type='date' placeholder='Wann?' style='padding:20px;border:none;border-radius: 6px;margin-left:3px;color:#909090;'><button style='background-color:#0387bb;padding:20px;border-radius:6px;border:none;margin-left:3px;color:#ffffff;'>'Los geht‘s!'</button></form>";




        document.body.appendChild(div3);

        var div4 = document.createElement('div');
        div4.setAttribute("style", "margin:0 auto;width:964px;display:flex");
        document.body.appendChild(div4);



        var left = document.createElement('div');
        left.setAttribute("style", "width:60%;margin:70px 0px 0px 0px;")
        div4.appendChild(left);

        var content1 = document.createElement('div');
        left.appendChild(content1);

        var leftImg = document.createElement('img');
        leftImg.src = "images/Video.jpg";
        left.appendChild(leftImg);

        var leftHead = document.createElement('h2');
        leftHead.innerText = "Vom Achtsitzer bis zum Luxusliner!";
        leftHead.setAttribute("style", "color:#f05a32; font-size:52px; line-height:60px;padding-top:56px;")
        left.appendChild(leftHead);

        var leftpara1 = document.createElement('p');
        leftpara1.innerText = "Starten Sie mit Ihrem Wunschbus durch! mietbus24.com ist Ihrerfahrener und zuverlässiger Partner für europaweite Busvermietungen und internationale Bustransfers.";
        leftpara1.setAttribute("style", "padding:30px 0px;color:#555555;font-size:18px;line-height:34px;")
        left.appendChild(leftpara1);

        var leftpara2 = document.createElement('p');
        leftpara2.innerText = "Sie bestimmen, wohin und wie Sie verreisen möchten, mietbus24.com vermittelt Ihnen den dafür passenden Bus. Ob Kurztrip, Flughafentransfer,Ausflug, bequeme Bustour, Messetransfer, Kurzstrecke oder lange Reise – Mieten Sie bei uns jede erdenkliche Form von Bussen für Ihre Busreise.";
        leftpara2.setAttribute("style", "padding-bottom:30px;color:#555555;font-size:18px;line-height:34px;")
        left.appendChild(leftpara2);

        var leftpara3 = document.createElement('p');
        leftpara3.innerHTML ="Wir richten uns nach Ihren individuellen Bedürfnissen und das zu fairen Preisen. Ob Klassenfahrt oder Großevent – Bei uns finden Sie garantiert den passenden Mietbus für eine angenehme Busreise vom Format S bis XXLInformieren Sie sich über unsere <a href='' style='color:#f05a32;; text-decoration:none;'>Leistungen</a>, stöbern Sie in unserer <a href=''style='color:#f05a32;; text-decoration:none;'>Fahrzeugflotte</a>und erfahren Sie mehr über das <a href=''style='color:#f05a32;; text-decoration:none;'>Busunternehmen Mietbus24</a>.";
                                                                                                                                                                                                                                                                                    

        leftpara3.setAttribute("style", "color:#555555;font-size:18px;line-height:34px;")
        left.appendChild(leftpara3);



        var right = document.createElement('div');
        right.setAttribute("style", "width:35%; margin:70px 0px 0px 30px")
        div4.appendChild(right);

        rightdiv1 = document.createElement('div');
        rightdiv1.setAttribute("style", "background-color:#f2692f;padding:25px;")
        right.appendChild(rightdiv1);

        righthead = document.createElement('h3')
        righthead.innerText = "Ihre Vorteile aufeinen Blick!";
        righthead.setAttribute("style", "margin-bottom:20px; font-size: 25px;line-height: auto;color: #fff;")
        rightdiv1.appendChild(righthead);

        ul = document.createElement('ul');
        ul.setAttribute("style", "list-style-position: inside;")

        rightdiv1.appendChild(ul);

        li1 = document.createElement('li')
        li1.innerHTML = "<img src='images/tick.png' alt=''>&nbsp;&nbsp;&nbsp;Europaweit"
        li1.setAttribute("style", "margin-bottom:20px;font-size: 14pt;line-height: 28px;color: #fff;list-style-type:none;")
        rightdiv1.appendChild(li1);

        li1 = document.createElement('li')
        li1.innerHTML = "<img src='images/tick.png' alt=''>&nbsp;&nbsp;&nbsp;Fairer Preis"
        li1.setAttribute("style", "margin-bottom:20px;font-size: 14pt;line-height: 28px;color: #fff;list-style-type:none;")
        rightdiv1.appendChild(li1);

        li1 = document.createElement('li')
        li1.innerHTML = "<img src='images/tick.png' alt=''>&nbsp;&nbsp;&nbsp;Fahrzeugflotte von S bis XXL"
        li1.setAttribute("style", "margin-bottom:20px;font-size: 14pt;line-height: 28px;color: #fff;list-style-type:none;")
        rightdiv1.appendChild(li1);

        li1 = document.createElement('li')
        li1.innerHTML = "<img src='images/tick.png' alt=''>&nbsp;&nbsp;&nbsp;flexible Angebote"
        li1.setAttribute("style", ";margin-bottom:20px;font-size: 14pt;line-height: 28px;color: #fff;list-style-type:none;")
        rightdiv1.appendChild(li1);


        rightdiv2 = document.createElement('div');
        rightdiv2.setAttribute("style", "border: 1px solid #f16130;text-align: center;margin-top: 30px; padding:28px 0px;");
        right.appendChild(rightdiv2);

        righthead2 = document.createElement('h3')
        righthead2.innerHTML = "Wünschen <br>SieBeratung?";
        righthead2.setAttribute("style", "font-size: 28px;line-height: 27px; color: #f05a32;padding: 17px 0px;");
        rightdiv2.appendChild(righthead2);


        rightpara4 = document.createElement('p')
        rightpara4.innerHTML = "Gerne beraten wir Sie auch <br>persönlich.";
        rightpara4.setAttribute("style", " font-size: 16px;line-height: 22px;color: #f6a899;");
        rightdiv2.appendChild(rightpara4);

        rightpara5 = document.createElement('p')
        rightpara5.innerHTML = "Gerne beraten wir Sie auch <br>persönlich.";
        rightpara5.setAttribute("style", "font-size: 16px;line-height: 22px;color: #f6a899; padding:0px 0px 30px 0px;");
        rightdiv2.appendChild(rightpara5);

        anchor = document.createElement('a');
        anchor.innerHTML = " Anfrage stellen ";
        anchor.setAttribute("style", "background-color:#0388bc;padding:15px 30px; border-radius: 2px ; color: #fff; border: none;");
        rightdiv2.appendChild(anchor);


        rightdiv3 = document.createElement('div');
        rightdiv3.setAttribute("style", "border: 1px solid red;text-align:center;margin-top:30px;");
        right.appendChild(rightdiv3);

        rightdiv3head = document.createElement('h4');
        rightdiv3head.setAttribute("style", "padding: 23px 0 8px; color: #f05a32;font-size:26px;line-height:34px;");
        rightdiv3head.innerHTML = 'Unsere Partner'
        rightdiv3.appendChild(rightdiv3head);


        var rightImg1 = document.createElement('img');
        rightImg1.setAttribute('style', ' padding: 20px 0;')
        rightImg1.src = "images/Ebene1.png";
        rightdiv3head.appendChild(rightImg1);

        var rightImg2 = document.createElement('img');
        rightImg2.setAttribute('style', ' padding: 20px 0;')
        rightImg2.src = "images/Ebene2.png";
        rightdiv3head.appendChild(rightImg2);

        var rightImg3 = document.createElement('img');
        rightImg3.setAttribute('style', ' padding: 20px 0;')
        rightImg3.src = "images/Ebene3.png";
        rightdiv3head.appendChild(rightImg3);




        var footer = document.createElement('footer');
        footer.setAttribute('style', ' background-color: #ececec; margin-top: 65px;padding-bottom:20px;');
        document.body.appendChild(footer);

        var div5 = document.createElement('div');;
        div5.setAttribute("style", "margin:0 auto;width:964px;display:flex;justify-content:space-between;");
        footer.appendChild(div5);



        ftxt1 = document.createElement('div');

        // ftxt1.setAttribute('style','font-size:32px;');
        div5.appendChild(ftxt1);

        ftxt1head = document.createElement('h3');
        ftxt1head.setAttribute('style', "color: #f05a32;padding-top: 25px ; font-size: 29px;line-height: 38px;");
        ftxt1head.innerHTML = 'Reisen';
        ftxt1.appendChild(ftxt1head);

        ftxt1p = document.createElement('p');
        ftxt1p.setAttribute('style', "color: #555555;padding: 26px 0px;font-size: 11pt;line-height: 20px;");
        ftxt1p.innerHTML = "Spanien, Italien, Ungarn oder Frankreich,<br> ob Jugend-, Klassen- oder Gruppenreise,<br> Bus-, Flug- oder Eigenanreise <br>- alles ist möglich";

        ftxt1.appendChild(ftxt1p);

        ftxt1a = document.createElement('a');
        ftxt1a.setAttribute('style', "background-color: #0384b7;text-decoration:none;color: #fff;border: none;border-radius: 2px;padding: 10px 15px;");
        ftxt1a.innerHTML = 'Jetzt auswählen';
        ftxt1.appendChild(ftxt1a);


        ftxt2 = document.createElement('div');

        // ftxt1.setAttribute('style','font-size:32px;');
        div5.appendChild(ftxt2);


        ftxt2head = document.createElement('h3');
        ftxt2head.setAttribute('style', "color: #f05a32;padding-top: 25px ; font-size: 29px;line-height: 38px;");
        ftxt2head.innerHTML = '24h-Service';
        ftxt2.appendChild(ftxt2head);

        ftxt2p = document.createElement('p');
        ftxt2p.setAttribute('style', "color: #555555;padding: 26px 0px;font-size: 11pt;line-height: 20px;");
        ftxt2p.innerHTML = "Spanien, Italien, Ungarn oder Frankreich,<br> ob Jugend-, Klassen- oder Gruppenreise,<br> Bus-, Flug- oder Eigenanreise <br>- alles ist möglich";

        ftxt2.appendChild(ftxt2p);

        ftxt2a = document.createElement('a');
        ftxt2a.setAttribute('style', "background-color: #0384b7;text-decoration:none;color: #fff;border: none;border-radius: 2px;padding: 10px 15px;");
        ftxt2a.innerHTML = 'Serviceangebot';
        ftxt2.appendChild(ftxt2a);


        ftxt3 = document.createElement('div');

        // ftxt1.setAttribute('style','font-size:32px;');
        div5.appendChild(ftxt3);


        ftxt3head = document.createElement('h3');
        ftxt3head.setAttribute('style', "color: #f05a32;padding-top: 25px ; font-size: 29px;line-height: 38px;");
        ftxt3head.innerHTML = 'ragen?';
        ftxt3.appendChild(ftxt3head);

        ftxt3p = document.createElement('p');
        ftxt3p.setAttribute('style', "color: #555555;padding: 26px 0px;font-size: 11pt;line-height: 20px;");
        ftxt3p.innerHTML = "Spanien, Italien, Ungarn oder Frankreich,<br> ob Jugend-, Klassen- oder Gruppenreise,<br> Bus-, Flug- oder Eigenanreise <br>- alles ist möglich";

        ftxt3.appendChild(ftxt3p);

        ftxt3a = document.createElement('a');
        ftxt3a.setAttribute('style', "background-color: #0384b7;text-decoration:none;color: #fff;border: none;border-radius: 2px;padding: 10px 15px;");
        ftxt3a.innerHTML = 'Fragen klären';
        ftxt3.appendChild(ftxt3a);


        footer2 = document.createElement('div');
        footer2.setAttribute('style', "background-color: #383838; margin-bottom:10px;")
        document.body.appendChild(footer2);

        var div6 = document.createElement('div');;
        div6.setAttribute("style", "margin:0 auto;width:964px;display:flex;justify-content:space-between;padding:25px 0px;font-size:18px;line-height: 20px;color: #949494;");
        footer2.appendChild(div6);

        ftxt2p1 = document.createElement('p');
        ftxt2p1.innerHTML = 'Copyright © 2014 mietbus24';
        div6.appendChild(ftxt2p1);

        ftxt2p2 = document.createElement('p');
        ftxt2p2.innerHTML = 'Busanfrage ·  Kontakt ·  FAQ ·  AGB ·  Impressum';
        div6.appendChild(ftxt2p2);























